"""Validate an empirical overlay mapping with real F1 positive/negative controls."""
import argparse
import json
import mmap
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time


def save(path, value):
    path.write_text(json.dumps(value, indent=2), encoding='utf-8')


def validate(d, model):
    assert d['status'] == 'diagnostic_completed_not_certified'
    assert d['boot_id'] == Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    assert d['mountinfo'] == Path('/proc/self/mountinfo').read_text(), 'Mount layout changed'
    assert d['model'] == str(model)
    assert len(d['trials']) == 3
    candidates = set(d['trials'][0]['disk_read_deltas'])
    for t in d['trials']:
        assert t['direct_read']['exit_code'] == 0
        candidates &= {k for k, v in t['disk_read_deltas'].items() if v == t['bytes']}
    assert len(candidates) == 1, 'No unique empirical device'
    device = candidates.pop()
    assert d['idle_read_bytes_3s'][device] == 0
    assert (Path('/sys/block') / device).exists()
    return device


def direct_read(path, count):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECT)
    try:
        with mmap.mmap(-1, 1024**2) as buf:
            for _ in range(count):
                assert os.readv(fd, [buf]) == len(buf)
    finally:
        os.close(fd)


def worker(args):
    from arm_validity import ArmWatch
    d = json.loads(Path(args.diagnostic).read_text())
    model = Path(d['model'])
    device = validate(d, model)
    out = Path(args.out)
    def resolver(path):
        assert Path(path).resolve() == model.resolve(), 'Mapping limited to tested model'
        return device
    with ArmWatch(arm=args.worker, round=1, run=1, model_path=str(model),
                  disk_device=resolver) as watch:
        (out / 'ready').touch()
        if args.worker == 'own':
            direct_read(args.file, 128)
        elif args.worker == 'foreign':
            until = time.monotonic() + 90
            while not (out / 'done').exists():
                if time.monotonic() > until:
                    raise TimeoutError('Foreign control did not finish')
                time.sleep(.1)
        else:
            time.sleep(3)
    save(out / 'watch.json', watch.record)


def main():
    root = Path('/workspace/vast_runner')
    diagnostics = sorted((root/'work').glob('overlay_diagnostic_*/diagnostic.json'))
    assert diagnostics, 'Run diagnose_overlay.py first'
    diagnostic = diagnostics[-1]
    d = json.loads(diagnostic.read_text())
    model = Path(d['model'])
    device = validate(d, model)
    out = root/'work'/('overlay_control_' + str(time.time_ns()))
    out.mkdir()
    summary = {'status': 'incomplete', 'device': device, 'diagnostic': str(diagnostic),
               'scope': 'container-visible virtual disk; not physical-host certification',
               'controls': [], 'final_approved': False}
    try:
        with tempfile.TemporaryDirectory(prefix='vast_control_', dir=model.parent.parent) as tmp:
            payload = Path(tmp)/'payload.bin'
            subprocess.run(['dd', 'if=/dev/zero', 'of='+str(payload), 'bs=1M',
                            'count=1280', 'conv=fsync', 'status=none'], check=True, timeout=120)
            for case in ('baseline', 'own', 'foreign'):
                folder = out/case
                folder.mkdir()
                print('Control:', case, flush=True)
                with (folder/'process.log').open('w') as log:
                    child = subprocess.Popen([sys.executable, __file__, '--worker', case,
                        '--diagnostic', str(diagnostic), '--file', str(payload), '--out', str(folder)],
                        stdout=log, stderr=subprocess.STDOUT)
                    try:
                        until = time.monotonic()+60
                        while not (folder/'ready').exists():
                            if child.poll() is not None:
                                raise RuntimeError('Worker exited; see '+str(folder/'process.log'))
                            if time.monotonic()>until:
                                raise TimeoutError('Worker not ready')
                            time.sleep(.1)
                        if case == 'foreign':
                            # Parent is outside the watcher's process tree.
                            direct_read(str(payload), 1280)
                            (folder/'done').touch()
                        assert child.wait(timeout=100) == 0, 'Control worker failed'
                    finally:
                        if child.poll() is None:
                            child.kill()
                            child.wait()
                record = json.loads((folder/'watch.json').read_text())
                observed = record['checks']['foreign_reads']['outcome']
                expected = 'void' if case == 'foreign' else 'ok'
                summary['controls'].append({'case': case, 'expected': expected, 'observed': observed})
                assert observed == expected, 'Control mismatch; do not use mapping'
        summary['status'] = 'controls_passed'
    except Exception as exc:
        summary['error'] = repr(exc)
    finally:
        save(out/'summary.json', summary)
        print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--worker', choices=['baseline', 'own', 'foreign'])
    p.add_argument('--diagnostic')
    p.add_argument('--file')
    p.add_argument('--out')
    args = p.parse_args()
    if args.worker:
        worker(args)
    else:
        main()
