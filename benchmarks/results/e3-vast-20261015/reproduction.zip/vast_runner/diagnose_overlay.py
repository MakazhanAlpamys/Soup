"""Standalone container disk diagnostic; never changes F1 or training results."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time


def command(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=60)
    return dict(command=args, exit_code=p.returncode, stdout=p.stdout, stderr=p.stderr)


def counters():
    return {f[2]: int(f[5]) * 512 for line in Path('/proc/diskstats').read_text().splitlines()
            if len(f := line.split()) >= 14}


def main():
    root = Path('/workspace/vast_runner')
    out = root / 'work' / ('overlay_diagnostic_' + str(time.time_ns()))
    out.mkdir(parents=True)
    report = {'status': 'diagnostic_only', 'F1_approved': False, 'trials': []}
    try:
        report['boot_id'] = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        report['mountinfo'] = Path('/proc/self/mountinfo').read_text()
        report['devices'] = command(['lsblk', '-J', '-o', 'NAME,MAJ:MIN,SIZE,TYPE,MOUNTPOINTS'])
        prepared = json.loads((root / 'work/e3_prepared/prepared.json').read_text())
        model = Path(prepared['model'])
        report['model'] = str(model)
        report['model_mount'] = command(['findmnt', '-J', '-T', str(model)])
        report['paths'] = {}
        for path in [root, model, Path('/var/lib/docker/overlay2'), Path('/etc/hosts')]:
            try:
                st = path.stat()
                report['paths'][str(path)] = {'device': f'{os.major(st.st_dev)}:{os.minor(st.st_dev)}'}
            except OSError as exc:
                report['paths'][str(path)] = {'error': str(exc)}
        before = counters()
        time.sleep(3)
        after = counters()
        report['idle_read_bytes_3s'] = {k: after[k] - before[k] for k in before if k in after}
        # Files are created alongside model blobs, not on an assumed backing device.
        with tempfile.TemporaryDirectory(prefix='vast_mapping_', dir=model.parent.parent) as tmp:
            for mib in (64, 192, 64):
                path = Path(tmp) / f'trial_{len(report["trials"])}.bin'
                write = command(['dd', 'if=/dev/urandom', 'of=' + str(path), 'bs=1M',
                                 'count=' + str(mib), 'conv=fsync', 'status=none'])
                if write['exit_code']:
                    raise RuntimeError(str(write))
                before = counters()
                direct = command(['dd', 'if=' + str(path), 'of=/dev/null', 'bs=1M',
                                  'iflag=direct', 'status=none'])
                after = counters()
                report['trials'].append({'bytes': mib * 1024**2, 'direct_read': direct,
                    'disk_read_deltas': {k: after[k] - before[k] for k in before if k in after}})
                if direct['exit_code']:
                    raise RuntimeError('Direct read failed; no mapping inferred')
        report['status'] = 'diagnostic_completed_not_certified'
    except Exception as exc:
        report['error'] = repr(exc)
    finally:
        target = out / 'diagnostic.json'
        target.write_text(json.dumps(report, indent=2), encoding='utf-8')
        print(target, flush=True)


if __name__ == '__main__':
    main()
