"""Read-only archive audit and F1 repeat planning for exploratory E3."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import statistics as st
import zipfile

from arm_validity import Run, repeats, blocks_to_add


def analyze(path):
    summaries = []
    audit = []
    with zipfile.ZipFile(path) as z:
        def read(name):
            return json.loads(z.read(name))
        provenance = None
        gpu = None
        for length in (512, 2048, 4096):
            names = [n.rsplit('/', 1)[0] for n in z.namelist()
                     if n.startswith(f'work/e3_e3-overlay-{length}-') and n.endswith('/block_complete.json')]
            assert len(names) == 5, (length, names)
            names.sort()
            blocks, rows = [], []
            for name in names:
                assert read(name+'/block_complete.json')['status'] == 'single_block_completed'
                block = []
                for index, method in enumerate(('lora', 'lorafa', 'lorafa', 'lora')):
                    base = f'{name}/arm_{index}_{method}/'
                    raw = z.read(base+'result.json')
                    r, w = json.loads(raw), read(base+'watch.json')
                    assert hashlib.sha256(raw).hexdigest() == w['result_sha256']
                    assert read(base+'process/process.json')['exit_code'] == 0
                    assert r['status'] == 'completed_preliminary'
                    assert w['process_status'] == 'completed' and w['F1']['outcome'] == 'ok'
                    assert all(w['F1']['checks'][k]['outcome'] == 'ok' for k in ('suspend','power','foreign_reads'))
                    assert r['method'] == method and r['length'] == length
                    assert len(r['step_seconds']) == r['steps_requested'] == 32768//length
                    assert r['warmup_steps'] == 2
                    t = r['configuration']['training']
                    assert t['batch_size'] == 1 and t['seed'] == 42 and t['stream_source'] == 'ram'
                    assert t['lora'] == {'r':16,'alpha':32,'target_modules':['q_proj','v_proj']}
                    if provenance is None:
                        provenance = r['provenance']
                        gpu = w['F1']['gpu']['id']
                    assert r['provenance'] == provenance and w['F1']['gpu']['id'] == gpu
                    median = st.median(r['step_seconds'][2:])
                    assert abs(median - w['median_step_s']) < 1e-12
                    block.append(Run(value=median, outcome='ok'))
                    rows.append({'method':method, 'step_s':median, 'tok_s':(length-1)/median,
                        'allocated_GiB':r['peak_allocated_bytes']/2**30,
                        'reserved_GiB':r['peak_reserved_bytes']/2**30,
                        'optimizer_MiB':r['optimizer_state_bytes']/2**20,
                        'loss_512':r['validation_after']['loss'],
                        'loss_long':r['validation_long_after']['loss']})
                blocks.append(block)
                audit.append(name)
            methods = {}
            for method in ('lora','lorafa'):
                rs = [r for r in rows if r['method']==method]
                methods[method] = {k: {'mean':st.mean(r[k] for r in rs),
                    'min':min(r[k] for r in rs), 'max':max(r[k] for r in rs)}
                    for k in rs[0] if k!='method'}
            differences = [(b[1].value+b[2].value-b[0].value-b[3].value)/2 for b in blocks]
            summaries.append({'length':length,'blocks':len(blocks),'arms':len(rows),
                'repeat_rule':asdict(repeats(blocks)), 'blocks_to_add':blocks_to_add(blocks),
                'mean_paired_step_difference_s':st.mean(differences),
                'sd_paired_step_difference_s':st.stdev(differences),
                'FA_step_increase_percent':100*(methods['lorafa']['step_s']['mean']/methods['lora']['step_s']['mean']-1),
                'methods':methods})
        return {'archive':str(path),'archive_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'formal_acceptance':False,'audited_blocks':audit,'summaries':summaries,
            'provenance':provenance,'gpu_uuid':gpu,
            'exclusions':['Original unadapted block: required foreign_reads unknown',
                '512 block04: entire incomplete block excluded, foreign reads 4688121856 bytes; replacement01 used'],
            'limitations':['Protocol not Git-committed before first arms; exploratory series',
                'F1 resolver observes virtual disk, not all physical-host activity',
                'Single model, rank/targets, seed; short 32768-input-token training; no convergence claim',
                '64/16/8 steps across lengths, so compare methods within length',
                'Timing excludes data fetch/eval/save; allocated memory is not total device VRAM',
                'F1 plans for 10 percent effect; passing sample count is not itself a significance test']}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('archive', type=Path)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    result = analyze(a.archive)
    a.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    for s in result['summaries']:
        print(s['length'], 'blocks=',s['blocks'], 'additional=',s['blocks_to_add'],
              'sigma=',s['repeat_rule']['sigma'], 'FA_step_increase_percent=',s['FA_step_increase_percent'])
