"""Bounded exploratory top-up to five blocks per length; no automatic retries."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

from run import ROOT, DATA, save, verify, bundle


def complete(job):
    marker = job/'block_complete.json'
    if not marker.exists():
        return False
    block = json.loads(marker.read_text())
    assert block['status'] == 'single_block_completed'
    for i, method in enumerate(('lora', 'lorafa', 'lorafa', 'lora')):
        arm = job/f'arm_{i}_{method}'
        w = json.loads((arm/'watch.json').read_text())
        assert w['process_status'] == 'completed' and w['F1']['outcome'] == 'ok'
        assert hashlib.sha256((arm/'result.json').read_bytes()).hexdigest() == w['result_sha256']
    return True


def main():
    verify()
    raw = (ROOT/'e3_repeat_protocol.json').read_bytes()
    protocol = json.loads(raw)
    declaration = DATA/'e3_repeat_declaration'
    declaration.mkdir(exist_ok=True)
    sources = [ROOT/'e3_repeat_protocol.json', ROOT/'e3_repeat_series.py', ROOT/'run_overlay_e3.py']
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    saved = declaration/'declaration.json'
    if saved.exists():
        assert json.loads(saved.read_text())['hashes'] == hashes, 'Series sources changed'
    else:
        save(saved, {'declared_unix_s': time.time(), 'hashes': hashes,
                     'formal_F1_acceptance': False, 'protocol': protocol})
        for p in sources:
            (declaration/(p.name+'.txt')).write_bytes(p.read_bytes())
    for length in protocol['lengths']:
        assert complete(DATA/f'e3_e3-overlay-{length}-block01'), 'Original block missing or invalid'
    started = time.monotonic()
    try:
        for number in protocol['additional_blocks']:
            for length in protocol['lengths']:
                ident = f'e3-overlay-{length}-block{number:02d}'
                job = DATA/('e3_'+ident)
                if job.exists():
                    assert complete(job), 'Incomplete block retained; review before continuing'
                    print('Already completed:', ident, flush=True)
                    continue
                remaining = 3600 - (time.monotonic() - started)
                assert remaining > 0, 'One-hour series cap reached; review before continuing'
                print('Starting', ident, flush=True)
                # Keep the tested wrapper's process-group timeout handling intact.
                # The one-hour limit prevents starting more blocks; it does not cut an active block.
                p = subprocess.run([str(ROOT/'.venv/bin/python'), str(ROOT/'run_overlay_e3.py'),
                    '--length', str(length), '--id', ident])
                assert p.returncode == 0, 'Block failed; inspect bundle'
                assert complete(job), 'Missing completion evidence'
        print('Five exploratory blocks per length completed; statistical review next.', flush=True)
    finally:
        bundle()


if __name__ == '__main__':
    main()
