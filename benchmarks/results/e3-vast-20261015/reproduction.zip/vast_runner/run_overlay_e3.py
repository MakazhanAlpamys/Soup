"""E3-only overlay resolver, preserving F1 counters, thresholds and refusal."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import uuid

from run import ROOT, DATA, environment, execute, save, verify
from overlay_control import validate


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_control_records(records, model, device):
    for case, expected in [('baseline', 'ok'), ('own', 'ok'), ('foreign', 'void')]:
        r = records[case]
        assert r['outcome'] == expected, case
        for name in ('suspend', 'power'):
            assert r['checks'][name]['outcome'] == 'ok', name
        c = r['checks']['foreign_reads']
        e = c['evidence']
        assert c['outcome'] == expected
        assert e['device'] == device and e['model_path'] == model
        delta = e['disk_read_bytes_end'] - e['disk_read_bytes_start']
        if case == 'baseline':
            assert delta == 0 and e['own_read_bytes'] == 0
        elif case == 'own':
            assert delta == 128 * 1024**2 and e['own_read_bytes'] == delta
            assert e['foreign_read_bytes_max'] == 0
        else:
            assert delta == 1280 * 1024**2 and e['own_read_bytes'] == 0
            assert e['foreign_read_bytes_min'] == delta


def evidence(folder):
    summary_path = folder / 'summary.json'
    summary = json.loads(summary_path.read_text())
    assert summary['status'] == 'controls_passed'
    diagnostic_path = Path(summary['diagnostic'])
    d = json.loads(diagnostic_path.read_text())
    model = json.loads((DATA/'e3_prepared/prepared.json').read_text())['model']
    device = validate(d, Path(model))
    assert summary['device'] == device
    paths = [summary_path, diagnostic_path]
    records = {}
    for case in ('baseline', 'own', 'foreign'):
        p = folder/case/'watch.json'
        paths.append(p)
        records[case] = json.loads(p.read_text())
    check_control_records(records, model, device)
    paths += [Path(__file__), ROOT/'overlay_control.py']
    return {'device': device, 'model': model,
            'hashes': {str(p): digest(p) for p in paths},
            'scope': 'empirical mapping of newly downloaded E3 files to container-visible disk; '
                     'no physical host isolation guarantee', 'final_approved': False}


def main(args):
    verify()
    if args.child:
        import block
        from arm_validity import ArmWatch
        spec = json.loads(args.child.read_text())
        folder = Path(spec['overlay_controls'])
        expected = json.loads((args.child.parent/'overlay_evidence.json').read_text())
        assert evidence(folder) == expected, 'Evidence or environment changed'
        class MappedWatch(ArmWatch):
            def __init__(self, *a, **kw):
                assert evidence(folder) == expected, 'Recalibrate after environment changes'
                def resolver(path):
                    assert str(Path(path)) == expected['model'], 'Untested path'
                    return expected['device']
                kw['disk_device'] = resolver
                super().__init__(*a, **kw)
        block.ArmWatch = MappedWatch
        block.main(args.child)
        return
    assert args.id and args.id.replace('-', '').replace('_', '').isalnum()
    candidates = sorted(DATA.glob('overlay_control_*/summary.json'))
    assert candidates, 'Run overlay_control.py first'
    controls = candidates[-1].parent
    cert = evidence(controls)
    job = DATA/('e3_'+args.id)
    # Never reuse an arm measured with different resolver semantics.
    job.mkdir(exist_ok=False)
    save(job/'overlay_evidence.json', cert)
    for source in (Path(__file__), ROOT/'overlay_control.py'):
        (job/(source.name+'.txt')).write_text(source.read_text(), encoding='utf-8')
    spec = {'task': 'e3', 'length': args.length, 'pair': '1,2', 'id': args.id,
            'exploratory': True, 'final_approved': False,
            'manifest_sha256': digest(ROOT/'manifest.json'),
            'overlay_controls': str(controls), 'overlay_evidence_sha256': digest(job/'overlay_evidence.json')}
    save(job/'spec.json', spec)
    env = environment('e3')
    env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    execute([str(ROOT/'.venv/bin/python'), str(Path(__file__).resolve()), '--child', str(job/'spec.json')],
            job/('invocation_'+uuid.uuid4().hex[:8]), env, timeout=10800)
    print('E3 block finished. Run: python3 run.py bundle', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--id')
    parser.add_argument('--length', type=int, choices=[512, 2048, 4096], default=2048)
    parser.add_argument('--child', type=Path)
    main(parser.parse_args())
